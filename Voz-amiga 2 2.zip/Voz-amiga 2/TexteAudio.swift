//
//  TexteAudio.swift
//  Voz-amiga
//
//  Created by Student21 on 27/09/23.
//

import SwiftUI

struct TexteAudio: View {
    
    @State var record = false
    
    var body: some View {
        NavigationLink{
            VStack{
                Button(action: {
                    // Ação a ser executada quando o botão for pressionado
                    print("Botão foi pressionado!")
                }) {
                    Text("gravre")
                        .font(.headline)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                    .cornerRadius(10)}
                
                if self.record{
                    
                }
            }
        }
    }
}

struct TexteAudio_Previews: PreviewProvider {
    static var previews: some View {
        TexteAudio()
    }
}
