//
//  ContentView.swift
//  Voz-amiga
//
//  Created by Student21 on 21/09/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        TabView{

            ScreenTwo()
                .tabItem{
                Label("Entrada", systemImage: "house")
            }
            
            ScreenOne()
                .tabItem{
                    Label("Alarmes", systemImage: "clock.badge")
                }
            
            
            Config()
                .tabItem{
                Label("Configurações", systemImage: "gear")
            }
            
        }
        .accentColor(.black)
        
    }
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
