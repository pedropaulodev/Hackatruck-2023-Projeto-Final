//
//  Alarm.swift
//  Voz-amiga
//
//  Created by Student21 on 22/09/23.
//

import SwiftUI
import AVFoundation


struct Alarm: View {
    
    @State private var isVisible = false
        let delayInSeconds = 3.0
        
        // Inicialize o player de áudio
        let audioPlayer: AVAudioPlayer? = {
            if let path = Bundle.main.path(forResource: "seu_som", ofType: "mp3") {
                do {
                    let url = URL(fileURLWithPath: path)
                    return try AVAudioPlayer(contentsOf: url)
                } catch {
                    print("Erro ao inicializar o player de áudio.")
                }
            }
            return nil
        }()
    
    var body: some View {
        ZStack{
            VStack{
                HStack{
                    Spacer()
                    Image("logo")
                        .resizable()
                        .frame(width: 50, height: 50)
                    Text("Voz Amiga")
                        .bold()
                        .font(.system(size: 24))
                    Spacer()
                }
                .frame(width: 380, height: 60)
                .background(
                    Color("Cor1")
                )
                
                Rectangle()
                    .frame( height: 25)
                
                VStack(){
                    Image("remedio")
                        .resizable()
                        .frame(width: 350, height: 250)
                        .overlay(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(Color.gray, lineWidth: 8)
                        )
                    
                    Text("20:30")
                        .bold()
                        .font(.system(size: 22))
                }
                
                HStack(){
                    Button(action: {
                        // Ação a ser executada quando o botão for pressionado
                        print("Botão foi pressionado!")
                    }) {
                        Image(systemName: "checkmark.seal")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundColor(.white)
                    }
                    .frame(width: 175, height: 200)
                    .background(Color.green)
                    // botao 2
                    Button(action: {
                        // Ação a ser executada quando o botão for pressionado
                        print("Botão foi pressionado!")
                    }) {
                        Image(systemName: "xmark.octagon.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundColor(.white)
                    }
                    .frame(width: 175, height: 200)
                    .background(Color.red)
                }
                Spacer()
            }
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipped()
        
    }
}

struct Alarm_Previews: PreviewProvider {
    static var previews: some View {
        Alarm()
    }
}

