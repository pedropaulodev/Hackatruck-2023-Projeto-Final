//
//  ScreenOne.swift
//  Voz-amiga
//
//  Created by Student21 on 22/09/23.
//

import SwiftUI

import AVFoundation
    

    class AudioRecorder: ObservableObject {
        var audioRecorder: AVAudioRecorder!
        
        func startRecording() -> String {
            let recordingSession = AVAudioSession.sharedInstance()
            do {
                try recordingSession.setCategory(.playAndRecord, mode: .default)
                try recordingSession.setActive(true)
            } catch {
                print("Failed to set up recording session")
            }
            
            let documentPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let currentDate = Date()
            let dateFormatter = DateFormatter()

            // Set Date Format
            dateFormatter.dateFormat = "YY, MMM d, hh:mm"
            
            let audioFilename = documentPath.appendingPathComponent("\(dateFormatter.string(from: currentDate)).m4a")
            let fullURL = "\(documentPath)\(audioFilename)"
            print("\(documentPath)\(audioFilename)")
            
            let settings = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 12000,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            
            do {
                audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
                audioRecorder.record()
                
                
            } catch {
                print("Could not start recording")
            }
            return fullURL
        }
        
        func stopRecording() {
            audioRecorder.stop()
        }
    }

struct ScreenOne: View {
    @StateObject var viewModel = ViewModel()
    
    
    @State var cores: String = "Cor1"
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    @State var i = 0
    
    var body: some View {
        NavigationStack{
            VStack{
                HStack{
                    Spacer()
                    Image("logo")
                        .resizable()
                        .frame(width: 50, height: 50)
                    Text("Voz Amiga")
                        .bold()
                        .font(.system(size: 24))
                    Spacer()
                }
                Rectangle()
                    .frame(width: 400,height: 12)
                ViewThatFits(in: .horizontal) {
                    HStack {
                        ScrollView{
                            LazyVGrid(columns: columns, spacing: 20) {
                                ForEach(viewModel.chars)
                                {
                                    lista in
                                    /*.onTapGesture {
                                     listaAlarmes.append(Alarmes(nome:"Novo Alarme" , audio:"Audio teste" , foto:"foto teste" ))
                                     listaAlarmes.swapAt(listaAlarmes.endIndex - 1, listaAlarmes.endIndex - 2)
                                     }*/
                                    
                                    NavigationLink {
                                        ScreenThree(booleana: false, hora: "00")
                                    } label: {
                                        ZStack{
                                            Rectangle()
                                                .fill(.black)
                                                .cornerRadius(10)
                                                .frame(width: 145,height: 135)
                                            Rectangle()
                                                .fill(Color(cores))
                                                .cornerRadius(10)
                                                .frame(width: 130,height: 115)
                                                                    //Text(lista.foto!)
                                                if let uiImage = UIImage(contentsOfFile: lista.foto!.path) {
                                                       // For iOS
                                                    Image(uiImage: uiImage).resizable().cornerRadius(10)
                                                        .frame(width: 130,height: 115)
                                                   }
                                                
                                            
                                        }
                                        .padding(15)
                                    }
                                    
                                    
                                }
                                NavigationLink {
                                    ScreenThree(booleana: true)
                                } label: {
                                    Image("appendButton").resizable().aspectRatio(contentMode: .fit)
                                        .frame(height: 135)
                                }
                            }
                            
                            
                            
                        }
                    }
                }
                .padding()
                .frame(maxWidth: .infinity)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(cores))
            .onAppear(){
                viewModel.fetch()
                
                Timer.scheduledTimer(withTimeInterval: 3, repeats: true){
                    _ in
                    
                    viewModel.fetch()
                }
            }
        }
    }
}


struct ScreenOne_Previews: PreviewProvider {
    static var previews: some View {
        ScreenOne()
    }
}

