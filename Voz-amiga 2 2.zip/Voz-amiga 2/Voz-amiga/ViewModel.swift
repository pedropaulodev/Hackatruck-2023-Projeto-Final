
import Foundation


struct Global{
    static var hora : String = ""
}

struct Alarmes: Decodable, Hashable, Encodable, Identifiable {
    let id = UUID()
    let audio: URL?
    let foto: URL?
    let hora: String?
}


class ViewModel : ObservableObject {
    @Published var chars : [Alarmes] = []
    
    
    func fetch(){
        guard let url = URL(string: "http://192.168.128.31:1880/voz-amigaREAD" ) else{
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Alarmes].self, from: data)
                
                DispatchQueue.main.async {
                    self?.chars = parsed
                }
            }catch{
                print(error)
            }
        }
        
        task.resume()
    }
    
    func post(dict: Alarmes, booleana: Bool){
        if (booleana == true) {
            let encoder = JSONEncoder()
            let jsonData = try! encoder.encode(dict)
            let url = URL(string: "http://192.168.128.31:1880/voz-amigaPOST")
            var request = URLRequest(url: url!)
            request.httpMethod = "POST"
            request.httpBody = jsonData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    return
                }
                
                // Handle the response data
            }
            task.resume()
        }
    }
}
