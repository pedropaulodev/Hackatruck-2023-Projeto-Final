//
//  Voz_amigaApp.swift
//  Voz-amiga
//
//  Created by Student21 on 21/09/23.
//

import SwiftUI

@main
struct Voz_amigaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
