import SwiftUI

struct ScreenTwo: View {
    
    @State var cores: String = "Cor1"
    
    var body: some View {
        NavigationStack{
            VStack{
                HStack{
                    Spacer()
                    Image("logo")
                        .resizable()
                        .frame(width: 50, height: 50)
                    Text("Voz Amiga")
                        .bold()
                        .font(.system(size: 24))
                    Spacer()
                }
                Rectangle()
                    .frame(width: 400,height: 12)
                ZStack {
                    Image("family")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(.horizontal)
                        .opacity(0.2)
                    
                    VStack{
                        Text("Bem-vindo ao Voz Amiga, a sua agenda de medicamentos simples e fácil de usar. Este aplicativo foi criado para ajudar no cuidado de pessoas especiais, fornecendo lembretes diários para a administração de medicamentos ou para a execução de tarefas importantes. Ele utiliza recursos visuais e sonoros para auxiliar nos horários de tomar os remédios, tornando a gestão da saúde mais eficiente e conveniente.")
                            .font(.system(size: 22))
                            .foregroundColor(.black)
                            .padding(.all)
                            .multilineTextAlignment(.center)
                    }
                }
                Rectangle()
                    .frame(width: 400,height: 12)
            }
            .padding()
            .frame(maxWidth: .infinity)
            
            Spacer()
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(cores))
        
    }
    
}


struct ScreenTwo_Previews: PreviewProvider {
    static var previews: some View {
        ScreenTwo()
    }
}


