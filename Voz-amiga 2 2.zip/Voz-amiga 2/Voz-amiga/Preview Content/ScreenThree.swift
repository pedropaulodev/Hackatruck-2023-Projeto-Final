//
//  ScreenThree.swift
//  Voz-amiga
//
//  Created by Student21 on 22/09/23.
//

import SwiftUI
import PhotosUI

struct Teste: View {
    
    struct Horas : Identifiable {
        var id : String
    }
    struct Minutos : Identifiable {
        var id : String
    }
    struct Dias : Identifiable {
        var id : String
    }
    @State var hora: [Horas] = [
    Horas(id: "00"),
    Horas(id: "01"),
    Horas(id: "02"),
    Horas(id: "03"),
    Horas(id: "04"),
    Horas(id: "05"),
    Horas(id: "06"),
    Horas(id: "07"),
    Horas(id: "08"),
    Horas(id: "09"),
    Horas(id: "10"),
    Horas(id: "11"),
    Horas(id: "12"),
    Horas(id: "13"),
    Horas(id: "14"),
    Horas(id: "15"),
    Horas(id: "16"),
    Horas(id: "17"),
    Horas(id: "18"),
    Horas(id: "19"),
    Horas(id: "20"),
    Horas(id: "21"),
    Horas(id: "22"),
    Horas(id: "23")
    ]
    
    @State var minuto: [Minutos] = [
        Minutos(id: "00"),
        Minutos(id: "01"),
        Minutos(id: "02"),
        Minutos(id: "03"),
        Minutos(id: "04"),
        Minutos(id: "05"),
        Minutos(id: "06"),
        Minutos(id: "07"),
        Minutos(id: "08"),
        Minutos(id: "09"),
        Minutos(id: "10"),
        Minutos(id: "11"),
        Minutos(id: "12"),
        Minutos(id: "13"),
        Minutos(id: "14"),
        Minutos(id: "15"),
        Minutos(id: "16"),
        Minutos(id: "17"),
        Minutos(id: "18"),
        Minutos(id: "19"),
        Minutos(id: "20"),
        Minutos(id: "21"),
        Minutos(id: "22"),
        Minutos(id: "23"),
        Minutos(id: "24"),
        Minutos(id: "25"),
        Minutos(id: "26"),
        Minutos(id: "27"),
        Minutos(id: "28"),
        Minutos(id: "29"),
        Minutos(id: "30"),
        Minutos(id: "31"),
        Minutos(id: "32"),
        Minutos(id: "33"),
        Minutos(id: "34"),
        Minutos(id: "35"),
        Minutos(id: "36"),
        Minutos(id: "37"),
        Minutos(id: "38"),
        Minutos(id: "39"),
        Minutos(id: "40"),
        Minutos(id: "41"),
        Minutos(id: "42"),
        Minutos(id: "43"),
        Minutos(id: "44"),
        Minutos(id: "45"),
        Minutos(id: "46"),
        Minutos(id: "47"),
        Minutos(id: "48"),
        Minutos(id: "49"),
        Minutos(id: "50"),
        Minutos(id: "51"),
        Minutos(id: "52"),
        Minutos(id: "53"),
        Minutos(id: "54"),
        Minutos(id: "55"),
        Minutos(id: "56"),
        Minutos(id: "57"),
        Minutos(id: "58"),
        Minutos(id: "59"),
    ]
    
    @State var dia: [Dias] = [
        Dias(id: "Domingo"),
        Dias(id: "Segunda-feira"),
        Dias(id: "Terça-feira"),
        Dias(id: "Quarta-feira"),
        Dias(id: "Quinta-feira"),
        Dias(id: "Sexta-feira"),
        Dias(id: "Sábado"),
        
    ]
    
    @State var horas: String = "00"
    @State var minutos: String = "00"
    @State var dias:String = ""
    @Environment(\.dismiss) var dismiss

    
    var body: some View {
        VStack{
            Button {
                Global.hora = "\(horas):\(minutos)"
                
                dismiss()
                
            } label: {
                HStack{
                    Image(systemName: "")
                    Text("Voltar")
                    
                }
            }
            HStack{
                ScrollView{
                    ForEach(hora) { hora in
                        Text(hora.id)
                            .font(.title2)
                            .onTapGesture {
                                horas = hora.id
                            }
                    }
                }
                ScrollView{
                    ForEach(minuto) {minuto in
                        Text(minuto.id)
                            .font(.title2)
                            .onTapGesture {
                                minutos = minuto.id
                            }
                    }
                }
                ScrollView{
                    ForEach(dia) {dia in
                        Text(dia.id)
                            .font(.title2)
                            .onTapGesture {
                                dias = dia.id
                            }
                    }
                }
            }
            .frame(width: 350,height: 30)
            .font(.title)
            .fontWeight(.bold)
            VStack{
                Text("Alarme definido para:")
                    .font(.title)
                    .fontWeight(.bold)
                if(horas != "" && minutos != ""){
                    Text("\(horas):\(minutos), \(dias)")
                        .font(.title)
                        .fontWeight(.bold)
                }
            }
        }
    }
}

struct SheetView: View {
    
    @State var hora : String = "00"
    @State var minutos : String = "00"
    @Environment(\.dismiss) var dismiss

    var body: some View {
        Button {
            Global.hora = "\(hora):\(minutos)"
            
            dismiss()
            
        } label: {
            HStack{
                Image(systemName: "")
                Text("Voltar")
                
            }
        }
        HStack {
            Spacer()
            TextField("", text: $hora).keyboardType(.decimalPad).frame(width: 50).font(.largeTitle)
            Text(":").font(.largeTitle)
            TextField("", text: $minutos).keyboardType(.decimalPad).frame(width: 45).font(.largeTitle)
            Spacer()
        }
        
        .padding()
        
    }
}

struct buttonAnimation: ButtonStyle {
 
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: .infinity)
    }
}
struct ScreenThree: View {
    @ObservedObject var audioRecorder: AudioRecorder = AudioRecorder()
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @StateObject var viewModel = ViewModel()
    @State var selectedImageURL: URL?
    @State var booleana : Bool
    @State var audioURL = URL(string: "")
    @State var sheetShown: Bool = false
    //@Binding var shipName: String = ""
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    //     var voltar : some View {
    //        Button(action: {
    //
    //            self.presentationMode.wrappedValue.dismiss()
    //
    //            }) {
    //                HStack {
    //                    Image(systemName: "arrowshape.turn.up.backward.fill")
    //                    .aspectRatio(contentMode: .fit)
    //                    Text("Voltar")
    //                }
    //            }
    //        }
    
    @State var gravando = false
    @State var corMic = "desligado"
    
    @State var resizableMic: CGFloat = 130
    
    func switchCor() {
        if (gravando) {
            corMic = "ligado"
        } else {
            corMic = "desligado"
        }
    }
    
    //@Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
//    var voltar : some View {
//        Button(action: {
//
//            viewModel.post(dict: Alarmes(audio: audioURL, foto: selectedImageURL, hora: hora), booleana: booleana)
//
//            self.presentationMode.wrappedValue.dismiss()
//        }) {
//            HStack {
//                Image(systemName: "arrowshape.turn.up.backward.fill")
//                    .aspectRatio(contentMode: .fit)
//
//                Text("Voltar")
//            }
//        }
//    }
    
    @State var hora : String = "00:00"
    
    
    
    var body: some View {
        ZStack {
            
            Rectangle().foregroundColor(Color("fundo")) //.frame(height: 685)
            VStack {
                
                HStack {
                    Button(action: {
                        
                        viewModel.post(dict: Alarmes(audio: audioURL, foto: selectedImageURL, hora: hora), booleana: booleana)
                        
                        self.presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
//                            Image(systemName: "arrowshape.turn.up.backward.fill")
//                                .resizable().aspectRatio(contentMode: .fit).frame(height: 24).padding(.leading, 5).padding(.top, 10)
                            
                            Text("Concluir").font(Font.title3.weight(.semibold)).padding(.top, 16)
                        }
                    }

                    Image("vozamiga").resizable().aspectRatio(contentMode: .fit).frame(height:50).padding([.leading, .top], 10)
                    Spacer()
                }
                Spacer()
                Rectangle().frame(width: 350, height: 5)
                Spacer()
                HStack {
                    
                    //                    PhotosPicker(selection: $selectedItems, maxSelectionCount: 1,
                    //                                 matching: .images) {
                    PhotosPicker(selection: $selectedItems,
                    maxSelectionCount: 1,
                                 matching: .images)
                    {
                        
                        ZStack {
                            if let data = data, let uiimage = UIImage(data: data) {
                                Image(uiImage: uiimage).resizable().frame(width: 200, height: 200).padding(.trailing, -4).padding([.top], -5)
                            } else {
                                Rectangle().frame(height: 200).padding(.trailing, -4).padding([.top], -5).foregroundColor(.green)
                            }
                            Image(systemName: "camera.fill").resizable().aspectRatio(contentMode: .fit).frame(height: 70).foregroundColor(.white)
                        }.onChange(of: selectedItems) {
                            newValue in
                            guard let item = selectedItems.first else {
                                return
                            }
                            item.loadTransferable(type: Data.self) {
                                result in
                                switch result{
                                case .success(let data):
                                    if let data = data {
                                        self.data = data
                                        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(UUID().uuidString).jpg")
                                        do {
                                        try data.write(to: url)
                                        self.selectedImageURL = url
                                            print(selectedImageURL?.absoluteString ?? "DEU ERRO")
                                                        } catch {
                                                            print("Error saving image: \(error)")
                                                        }
                                    } else {
                                        print("nil")
                                    }
                                    
                                case .failure(let failure):
                                    fatalError("\(failure)")
                                }
                            }
                            
                        }
                    }
                    Button(action: {
                        
                        
                        
                    }, label: {
                        ZStack {
                            Rectangle().frame(height: 200).padding(.leading, -4).padding([.top], -5).foregroundColor(.red)
                            Image(systemName: "trash").resizable().aspectRatio(contentMode: .fit).frame(height: 70).foregroundColor(.white)
                        }
                        
                    })
                }.padding(.top, 7)
                Spacer()
                
                
                Button(action:{
                    gravando = false
                    corMic = "desligado"
                    resizableMic = 130
                   // self.audioRecorder.stopRecording()
                    print("stopped")
                    
                }) {
                    Image(systemName: "mic.fill").resizable().aspectRatio(contentMode: .fit).frame(height: resizableMic).padding([.top, .bottom], -4).foregroundColor(Color(corMic))
                        .animation( .easeInOut(duration: 0.15))
                }.simultaneousGesture(LongPressGesture(minimumDuration: 0.15).onEnded({
                    i in
                    gravando = true
                    corMic = "ligado"
                    resizableMic = 150
                    //audioURL = URL(string: //self.audioRecorder.startRecording())
                    print("started")
                })).buttonStyle(buttonAnimation())
                
                
                Spacer()
                HStack {
                    Button(action: {
                        sheetShown.toggle()
                    }, label: {
                        ZStack {
                            Rectangle().frame(height: 170).padding(.trailing, -4).foregroundColor(Color(.blue))
                            if (hora == "00:00") {
                                Image(systemName: "clock").resizable().aspectRatio(contentMode: .fit).frame(height: 70).foregroundColor(.white)
                            } else {
                                VStack {
                                    Text(hora).foregroundColor(.white).font(Font.largeTitle.weight(.bold))
                                    Image(systemName: "clock").resizable().aspectRatio(contentMode: .fit).frame(height: 70).foregroundColor(.white)
                                }
                            }
                        }
                    })

                }.sheet(isPresented: $sheetShown) {
                    Teste()
                    
                }.onAppear() {
                    hora = Global.hora
                }
                 
                Spacer()
                
            } .navigationBarBackButtonHidden(true)
                .onAppear(){
                    Timer.scheduledTimer(withTimeInterval: 1, repeats: true){ _ in
                        hora = Global.hora
                    }
                }
            
            
        }
        
    }
    
    
}

struct ScreenThree_Previews: PreviewProvider {
    static var previews: some View {
        ScreenThree(booleana: false)
    }
}

