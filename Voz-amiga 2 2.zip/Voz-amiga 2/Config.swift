//
//  Config.swift
//  Voz-amiga
//
//  Created by Student21 on 26/09/23.
//

import SwiftUI
import AVFoundation
import AudioToolbox

struct Config: View {
    @State private var isVisible = false
    let delayInSeconds = 5.0
    
    @State var automaticOn = false
    @State var shine = 50.0
    
    let audioPlayer: AVAudioPlayer? = {
            if let path = Bundle.main.path(forResource: "voz", ofType: "mp3") {
                do {
                    let url = URL(fileURLWithPath: path)
                    return try AVAudioPlayer(contentsOf: url)
                } catch {
                    print("Erro ao inicializar o player de áudio.")
                }
            }
            return nil
        }()
    
    var body: some View {
        
        ZStack{
            Form{
                Section(header: Text("Apparence")){
                    HStack{
                        Text("Vibrar")
                        Spacer()
                        Toggle("",isOn:$automaticOn)
                    }
                    
//                    HStack{
//                        Image(systemName: "sun.max.fill")
//                        Slider(value: $shine, in:0...100)
//                        Image(systemName: "sun.max.fill")
//                            .resizable()
//                            .frame(width: 25.0, height: 25.0)
//                    }
                }
            }
            
            if isVisible{
                VStack{
                    HStack{
                        Spacer()
                        Image("logo")
                            .resizable()
                            .frame(width: 50, height: 50)
                        Text("Voz Amiga")
                            .bold()
                            .font(.system(size: 24))
                        Spacer()
                    }
                    .frame(width: 380, height: 60)
                    .background(
                        Color("Cor1")
                    )
                    
                    Rectangle()
                        .frame( height: 25)
                    
                    VStack(){
                        Image("remedio")
                            .resizable()
                            .frame(width: 350, height: 250)
                            .overlay(
                                RoundedRectangle(cornerRadius: 2)
                                    .stroke(Color.gray, lineWidth: 8)
                            )
                        
                        Text("14:40")
                            .bold()
                            .font(.system(size: 22))
                    }
                    
                    HStack(){
                        Button(action: {
                            // Ação a ser executada quando o botão for pressionado
                            print("Botão foi pressionado!")
                            isVisible = false
                        }) {
                            Image(systemName: "checkmark.seal")
                                .resizable()
                                .frame(width: 70, height: 70)
                                .foregroundColor(.white)
                        }
                        .frame(width: 175, height: 200)
                        .background(Color.green)
                        // botao 2
                        Button(action: {
                            // Ação a ser executada quando o botão for pressionado
                            print("Botão foi pressionado!")
                            isVisible = false
                        }) {
                            Image(systemName: "xmark.octagon.fill")
                                .resizable()
                                .frame(width: 70, height: 70)
                                .foregroundColor(.white)
                        }
                        .frame(width: 175, height: 200)
                        .background(Color.red)
                    }
                    Spacer()
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipped()
        
        .onAppear{
            Timer.scheduledTimer(withTimeInterval: delayInSeconds, repeats: false){ _ in
                isVisible = true
                audioPlayer?.play()
                if (automaticOn == true) {
                    AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(kSystemSoundID_Vibrate)) {   }
                }
            }
        }
    }
}

struct Config_Previews: PreviewProvider {
    static var previews: some View {
        Config()
    }
}

